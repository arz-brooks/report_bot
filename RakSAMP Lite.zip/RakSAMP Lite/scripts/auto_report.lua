local sampev = require("samp.events")
require("addon")

local questions = {
    "Какой твой любимый цвет?",
    "Какая твоя мечта на работу?",
    "Какое у тебя любимое хобби?",
}

function sampev.onShowDialog(dialogId, style, title, button1, button2, text)
    if dialogId == 2 then -- Окно авторизации
        sendDialogResponse(dialogId, 1, -1, "arizonarp")
        return false;
    end

    if dialogId == 32 then -- Окно репорта
        sendDialogResponse(dialogId, 1, -1, questions[math.random(#questions)])
        return false;
    end

    if dialogId == 1333 then -- Окно с ответом на репорт
        sendDialogResponse(dialogId, 1, -1, "")
        return false;
    end

    if dialogId == 1332 then -- Окно с оценкой ответа
        sendDialogResponse(dialogId, 0, 0, "")
        return false;
    end
end

function sampev.onServerMessage(color, text)
    if text:find("[Подсказка] {DC4747}Вы можете задать вопрос в нашу техническую поддержку /report.") then
        sendInput("/report")
    end

    if text:find("%[Подсказка%] {FFFFFF}Администратор (.*) принялся за ваш репорт!") then
        local admin = text:match("%[Подсказка%] {FFFFFF}Администратор (.*) принялся за ваш репорт!")
        if admin ~= "Joseph_Brooks" then 
            print(string.format("Репорт взял другой администратор %s", admin))
            reconnect(30000) 
        end
    end

    if text:find('[Информация] {FFFFFF}Спасибо за ваш отзыв!') then reconnect(18000) end
end